# Build APK bằng GitHub Actions (dùng điện thoại Android)

1. Giải nén ZIP này. Trên GitHub repository, tải **nội dung bên trong thư mục DUAL_AI_DEBATE** lên thư mục gốc của nhánh `main`, giữ nguyên các thư mục `app/`, `server/` và `.github/`.
2. Đảm bảo repository có file `.github/workflows/android-apk.yml`.
3. Mở tab **Actions** của repository.
4. Chọn **Build DUAL AI DEBATE APK** → **Run workflow** → **Run workflow**.
5. Mở lần chạy mới nhất. Chỉ khi có dấu tích xanh (Success), kéo xuống **Artifacts** và tải `DUAL-AI-DEBATE-debug-APK`.
6. Giải nén tệp artifact ZIP để lấy `app-debug.apk`, rồi cài trên Android 13.

Nếu build thất bại, mở mục **Build debug APK**, chụp phần lỗi màu đỏ và gửi để kiểm tra.

## Lưu ý quan trọng
- Đây là APK debug để thử nghiệm, chưa phải bản phát hành ký số.
- APK hiện chưa thể tranh luận trực tuyến cho đến khi backend Node.js trong `server/` được triển khai lên máy chủ HTTPS và `backendUrl` trong `MainActivity.kt` được đổi thành địa chỉ `/debate` thực tế.
- Không đưa API key OpenAI hoặc Gemini vào mã Android hay repository. Đặt chúng dưới dạng biến môi trường/secrets trên máy chủ backend.
- Không tải `.env` có khóa bí mật lên GitHub; chỉ giữ `.env.example`.
